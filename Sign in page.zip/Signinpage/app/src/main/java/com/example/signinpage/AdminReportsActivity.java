package com.example.signinpage;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TimePicker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

public class AdminReportsActivity extends AppCompatActivity implements View.OnClickListener {
    private Button btnSignout;
    private RecyclerView rvReport;
    private View.OnClickListener onItemClickListener;
    private DatabaseReference database;
    private Report report;
    private ArrayList<Report> reports;
    private Calendar calendar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_reports);
        rvReport = (RecyclerView) findViewById(R.id.rvReport);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        rvReport.setLayoutManager(layoutManager);
        btnSignout = (Button) findViewById(R.id.btnSignout);
        btnSignout.setOnClickListener(this);
        database= FirebaseDatabase.getInstance().getReference();
        calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);

        // if alarm time has already passed, increment day by 1
        if (calendar.getTimeInMillis() <= System.currentTimeMillis()) {
            calendar.set(Calendar.MINUTE, calendar.get(Calendar.MINUTE) + 15);
        }

        Constraints mConstraints = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();

        if (Build.VERSION.SDK_INT >= 33) {

            if (ContextCompat.checkSelfPermission(AdminReportsActivity.this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                PeriodicWorkRequest myWorkRequest =
                        new PeriodicWorkRequest.Builder(MyWorker.class, 15, TimeUnit.MINUTES)
                                .setInitialDelay(/*calendar.getTimeInMillis() - System.currentTimeMillis()*/ 10000, TimeUnit.MILLISECONDS)
                                .addTag("mywork")
                                //.setInputData(new Data.Builder().putString("userID",mAuth.getUid()).build())
                                // Constraints
                                .build();

                // one time work
            /*WorkRequest uploadWorkRequest =
                    new OneTimeWorkRequest.Builder(MyWorker.class)
                            .build();*/

                WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                        "sendLogs",
                        ExistingPeriodicWorkPolicy.REPLACE,
                        myWorkRequest);
            }
        }
        else {
            PeriodicWorkRequest myWorkRequest =
                    new PeriodicWorkRequest.Builder(MyWorker.class, 15, TimeUnit.MINUTES)
                            .setInitialDelay(/*calendar.getTimeInMillis() - System.currentTimeMillis()*/ 1000, TimeUnit.MILLISECONDS)
                            .addTag("mywork")
                            //.setInputData(new Data.Builder().putString("userID",mAuth.getUid()).build())
                            // Constraints
                            .build();

            // one time work
            /*WorkRequest uploadWorkRequest =
                    new OneTimeWorkRequest.Builder(MyWorker.class)
                            .build();*/

            WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                    "sendLogs",
                    ExistingPeriodicWorkPolicy.REPLACE,
                    myWorkRequest);
        }





        database.child("reports").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                reports = new ArrayList<Report>();
                for (DataSnapshot reportSnapshot : snapshot.getChildren()) {
                    reports.add(reportSnapshot.getValue(Report.class));
                }
                ReportAdapter reportAdapter = new ReportAdapter(reports);
                rvReport.setAdapter(reportAdapter);
                reportAdapter.setOnItemClickListener(onItemClickListener);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        onItemClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RecyclerView.ViewHolder viewHolder = (RecyclerView.ViewHolder) view.getTag();
                int position = viewHolder.getAdapterPosition();

                Report reportItem = reports.get(position);

                Intent intent = new Intent(AdminReportsActivity.this, AdminViewReportActivity.class);
                intent.putExtra("report", reportItem);
                startActivity(intent);

            }
        };





    }

    @Override
    public void onClick(View view){
        if (view.getId() == btnSignout.getId()) {
            FirebaseAuth.getInstance().signOut();
            Intent i = new Intent(AdminReportsActivity.this, LoginActivity.class);
            startActivity(i);
        }
    }
}

