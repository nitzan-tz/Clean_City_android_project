package com.example.signinpage;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.usage.NetworkStats;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import com.google.android.gms.maps.model.LatLng;
import com.google.common.net.InternetDomainName;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.net.HttpCookie;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class AddReportActivity extends AppCompatActivity implements View.OnClickListener {
    private Spinner spType;
    private EditText etInformation;
    private EditText etOther;
    private ImageView imgPhoto;
    private Button btnAddPhotoFromGallery;
    private Button btnTakePhoto;
    private Button btnAddReport;
    private FirebaseAuth mAuth;

    private User currentUser;
    private DatabaseReference database;

    private String type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_report);
        spType = (Spinner) findViewById(R.id.spType);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.TypeOfHazard,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spType.setAdapter(adapter);
        spType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                type = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        type = "garbage";
        etInformation = (EditText) findViewById(R.id.etInformation);
        imgPhoto = (ImageView) findViewById(R.id.imgPhoto);
        btnAddPhotoFromGallery = (Button) findViewById(R.id.btnAddPhotoFromGallery);
        btnAddPhotoFromGallery.setOnClickListener(this);
        btnTakePhoto = (Button) findViewById(R.id.btnTakePhoto);
        btnTakePhoto.setOnClickListener(this);
        btnAddReport = (Button) findViewById(R.id.btnAddReport);
        btnAddReport.setOnClickListener(this);

        mAuth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance().getReference();

        database.child("users").child(mAuth.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                currentUser = dataSnapshot.getValue(User.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == btnAddReport.getId()) {

            SimpleDateFormat sdf = new SimpleDateFormat("'Date\n'dd-MM-yyyy '\n\nand\n\nTime\n'HH:mm:ss z");
            Double[] arrReportLocation = (Double[]) getIntent().getSerializableExtra("arrReportLocation");
            Double latitude = arrReportLocation[0];
            Double longitude = arrReportLocation[1];
            Report report= new Report(mAuth.getUid()+System.currentTimeMillis(), type, etInformation.getText().toString(), "", latitude, longitude, currentUser.getId(), currentUser.getName(), false, System.currentTimeMillis(), currentUser.getPhone(), currentUser.getAddress());
            database.child("reports").child(mAuth.getUid()).setValue(report);
            database.child("users").child(mAuth.getUid()).child("reports").child(report.getId()).setValue(report);
            Intent intent = new Intent(AddReportActivity.this, MapsActivity.class);
            startActivity(intent);
        }
    }

    public void onItemSelected(AdapterView<?> parent, View view,
                               int pos, long id) {
        parent.getItemAtPosition(pos).toString();
    }

    public void onNothingSelected(AdapterView<?> parent) {
    }
}